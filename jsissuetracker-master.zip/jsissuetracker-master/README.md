# JS Issue Tracker
This is the *JS Issue Tracker* sample application from the tutorial *Pure JavaScript - Building A Real-World Application From Scratch*. You can find the tutorial on http://CodingTheSmartWay.com.
